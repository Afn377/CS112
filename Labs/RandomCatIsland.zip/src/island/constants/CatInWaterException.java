package island.constants;

public class CatInWaterException extends Exception {
    public CatInWaterException() {
        super("Your cat fell in the water!");
    }
}
