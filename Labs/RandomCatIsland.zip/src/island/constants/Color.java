package island.constants;

public enum Color {
    WHITE, ORANGE, BLACK, BROWN, GREY;
}
