package queue;

/*
* Linked List Node which represents one rider waiting on a ride queue
*/
public class Rider {
    // DO NOT MODIFY
    public Rider next;
    public String name;
}
