package test;

import static org.junit.Assert.*;
import org.junit.*;

import island.*;
import island.constants.Color;

/**
 * This is a JUnit test class, used to test code
 * 
 * You should test the SmartCat class by designing Island test cases
 * and filling in the JUnit tests according to the assignment
 * description.
 * 
 * @author Colin Sullivan
 */
public class SmartCatTest {

    public static Island pathIsland = new Island(new String[][] {
            // WRITE YOUR CODE HERE
            { /* ... */ }
    });

    public static Island yarnIsland = new Island(new String[][] {
            // WRITE YOUR CODE HERE
            { /* ... */ }
    });

    public static Island mazeIsland = new Island(new String[][] {
            // WRITE YOUR CODE HERE
            { /* ... */ }
    });

    @Test
    public void testWalkPath() {
        // WRITE YOUR CODE HERE

    }

    @Test
    public void testCollectAllYarn() {
        // WRITE YOUR CODE HERE

    }

    @Test
    public void testSolveMaze() {
        // WRITE YOUR CODE HERE

    }

}
